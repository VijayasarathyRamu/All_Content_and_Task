let evenNumber = (num:number) =>{
    return (num%2==0) ? `${num} is even number` : `${num} is odd number`;
}
console.log(evenNumber(10));
console.log(evenNumber(9));