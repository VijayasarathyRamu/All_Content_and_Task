var evenNumber = function (num) {
    return (num % 2 == 0) ? "".concat(num, " is even number") : "".concat(num, " is odd number");
};
console.log(evenNumber(10));
console.log(evenNumber(9));
